<?php
require './dbkoneksi_per5.php';

if (isset($_POST['submit'])) {
    // Tangkap data dari form
    $kode = $_POST['kode'];    
    $nama = $_POST['nama'];
    $tmp_lahir = $_POST['tmp_lahir'];
    $tgl_lahir = $_POST['tgl_lahir'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $kelurahan_id = $_POST['kelurahan_id'];

    // Proses insert ke database
    try {
        $sql = "INSERT INTO pasien (kode, nama, tmp_lahir, tgl_lahir, gender, email, alamat, 
        kelurahan_id) 
        VALUES (?,?,?,?,?,?,?,?)";
        $stmt = $db->prepare($sql);
        $stmt->execute([$kode, $nama, $tmp_lahir, $tgl_lahir, $gender, $email, $alamat, $kelurahan_id]);

        // redirect ke halaman list
        header("Location: list_pasien.php");
    } catch (\Throwable $e) {
        echo "Error while insert data pasien";
        echo $e;
    }
}
