<?php
require_once './dbkoneksi_per5.php';

// 4) Buat quary SQL
$list_pasien = $db->query("SELECT * FROM pasien");

// 6) Tampilkan hasil query SQL

?>
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Kode</th>
            <th>Nama Pasien</th>
            <th>Gender</th>
            <th>Email</th>
        </tr>
    </thead>

    <tbody>
        <?php
        foreach ($list_pasien as $idx => $pasien) { ?>
                <tr>
                <td> <?= $idx + 1 ?> </td>
                <td> <?= $pasien->kode ?> </td>
                <td> <?= $pasien->nama ?> </td>
                <td> <?= $pasien->gender ?> </td>
                <td> <?= $pasien->email ?> </td>
                </tr>;
        <?php
        }
        ?>
    </tbody>
</table>